import React from 'react';
import { ReactDOM } from 'react-dom';

import App from './App';
import main1 from './main1';
import main2 from './main2';


ReactDOM.render( <
    App / >
    /React.StrictMode>
    document.getElementById('root')
);